﻿/*using System.Data.SqlClient;
using System.Threading.Tasks;
using System;
using Newtonsoft.Json;
using Webapi.Model;

namespace Webapi.Repository
{
    public class StudentRepository : IRepository
    {
        private readonly string _connectionString;

        public StudentRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task SaveDataAsync(string jsonData)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                var command = new SqlCommand("updateinsert", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@jsonData", jsonData ?? (object)DBNull.Value);

                await command.ExecuteNonQueryAsync();
                
            }
        }


        public async Task<string> GetDataAsync(int? id)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                var command = new SqlCommand("GetStudentsFromJson", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ID", id.HasValue ? (object)id.Value : DBNull.Value);

                try
                {
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return reader.GetString(0);
                        }
                    }
                }
                catch (SqlException ex)
                {
                    // Log the exception
                    throw new InvalidOperationException("Error executing SQL command.", ex);
                }
            }

            return null;
        }
    }
}*/
using System.Data.SqlClient;
using System.Threading.Tasks;
using System;
using Newtonsoft.Json;
using Webapi.Model;

namespace Webapi.Repository
{
    public class StudentRepository : IRepository
    {
        private readonly string _connectionString;

        public StudentRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task SaveDataAsync(string jsonData)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                var command = new SqlCommand("updateinsert", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@jsonData", jsonData ?? (object)DBNull.Value);

                try
                {
                    await command.ExecuteNonQueryAsync();
                }
                catch (SqlException ex)
                {
                    // Log the exception
                    throw new InvalidOperationException("Error executing SQL command.", ex);
                }
            }
        }

        public async Task<string> GetDataAsync(string jsonData)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                var command = new SqlCommand("GetStudentsFromJson", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@jsonData", jsonData);

                try
                {
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return reader.GetString(0);
                        }
                    }
                }
                catch (SqlException ex)
                {
                    // Log the exception
                    throw new InvalidOperationException("Error executing SQL command.", ex);
                }
            }

            return null;
        }
    }
}
