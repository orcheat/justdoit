﻿using System.Threading.Tasks;

namespace Webapi.Repository
{
    public interface IRepository
    {
        Task SaveDataAsync(string jsonData);
        Task<string> GetDataAsync(string jsonData);

    }
}

