﻿    using System;

    namespace Webapi.Model
    {
        public class MyData
        {
           public string jsonData { get; set; }
        }
    }
