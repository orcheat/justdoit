﻿using System.Threading.Tasks;
using Webapi.Repository;
using System;

namespace Webapi.Service
{
    public class DataService : IDataService
    {
        private readonly IRepository _repository;

        public DataService(IRepository repository)
        {
            _repository = repository;
        }

        public Task SaveDataAsync(string jsonData)
        {
            return _repository.SaveDataAsync(jsonData);
        }
            
        public Task<string> GetDataAsync(string jsonData) {
            return _repository.GetDataAsync(jsonData);
        }
    }
}


/*using System.Threading.Tasks;
using Webapi.Model;
using Webapi.Repository;

namespace Webapi.Service
{
    public class DataService : IDataService
    {
        private readonly IRepository _repository;

        public DataService(IRepository repository)
        {
            _repository = repository;
        }

        public Task SaveDataAsync(MyData data)
        {
            return _repository.SaveDataAsync(data);
        }

        public Task<MyData> GetDataAsync(int id)
        {
            return _repository.GetDataAsync(id);
        }
    }
}
*/