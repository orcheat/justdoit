﻿using System.Threading.Tasks;
namespace Webapi.Service
{
        public interface IDataService
        {
            Task SaveDataAsync(string jsonData);
            Task<string> GetDataAsync(string jsonData);
        }
}

//using System.Threading.Tasks;
//using Webapi.Model;

//namespace Webapi.Service
//{
//    public interface IDataService
//    {
//        Task SaveDataAsync(MyData data);
//        Task<MyData> GetDataAsync(int id);
//    }
//}
