﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using Webapi.Model;
using Webapi.Service;

namespace Webapi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MyDataController : ControllerBase
    {
        private readonly IDataService _dataService;

        public MyDataController(IDataService dataService)
        {
            _dataService = dataService;
        }

        [HttpPost("save")]
        public async Task<IActionResult> SaveData([FromBody] MyData jsonData)
        {
            if (jsonData == null || string.IsNullOrEmpty(jsonData.jsonData))
            {
                return BadRequest("Invalid JSON data");
            }

            // Directly use the jsonData.jsonData string
            var jsonString = jsonData.jsonData;

            // Check if the serialized JSON string is empty
            if (string.IsNullOrEmpty(jsonString))
            {
                return BadRequest("Empty JSON data");
            }

            try
            {
                await _dataService.SaveDataAsync(jsonString);
                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception (you might want to use a logging library)
                return StatusCode(StatusCodes.Status500InternalServerError, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("fetch")]
        public async Task<IActionResult> GetData([FromBody] MyData jsonData)
        {
            if (jsonData == null || string.IsNullOrEmpty(jsonData.jsonData))
            {
                return BadRequest("Invalid JSON data");
            }

            var data = await _dataService.GetDataAsync(jsonData.jsonData);
            if (data == null)
            {
                return NotFound();
            }
            return Ok(data);
        }
    }
}
